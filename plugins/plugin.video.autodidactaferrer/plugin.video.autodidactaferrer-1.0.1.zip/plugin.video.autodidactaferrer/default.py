﻿# -*- coding: utf-8 -*-
#------------------------------------------------------------
# http://www.youtube.com/
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import sys
import plugintools
import xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.autodidactaferrer'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
fanart = local.getAddonInfo('fanart')

yt_playlist = "UCbr0g_ADLsdzhcoAFUZkuug/playlist/PLEtcGQaT56chpYflEjBWRodHJNJN8EKpO"
yt_playlist_2 = "UCbr0g_ADLsdzhcoAFUZkuug/playlist/PLEtcGQaT56cj70Vl_C1qfUinyMELunL-N"
yt_playlist_3 = "UCbr0g_ADLsdzhcoAFUZkuug/playlist/PLEtcGQaT56chEhBYGzWJo8V5mmQABmRJe"
yt_playlist_4 = "UCbr0g_ADLsdzhcoAFUZkuug/playlist/PLEtcGQaT56ch6U2vN8u29OOnr5E90A_Ev"
yt_playlist_5 = "UCbr0g_ADLsdzhcoAFUZkuug/playlist/PLEtcGQaT56cgWfEWXD0GzF9UGYn7eL1kj"
yt_playlist_6 = "UCbr0g_ADLsdzhcoAFUZkuug/playlist/PLEtcGQaT56chIjXff_cAEglfe6gBSNFHj"
yt_playlist_7 = "UCbr0g_ADLsdzhcoAFUZkuug/playlist/PLEtcGQaT56chQN6n4byqRIMYnTHpgkG6m"
yt_playlist_8 = "UCbr0g_ADLsdzhcoAFUZkuug/playlist/PLEtcGQaT56cg3A3r-TNoc-PyVeOuAMB4x"
yt_playlist_9 = "UCbr0g_ADLsdzhcoAFUZkuug/playlist/PL12BD85C00C10E036"

# Entry point
def run():
    plugintools.log("cursopython.run")

    # Get params
    params = plugintools.get_params()

    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"

    plugintools.close_item_list()


# Main menu
def main_list(params):
    plugintools.log("multicine.main_list "+repr(params))

    plugintools.add_item(
        action="",
        title="Python Básico",
        url="plugin://plugin.video.youtube/channel/"+yt_playlist+"/",
        thumbnail=icon,
        fanart=fanart,
        folder=True)

    plugintools.add_item(
        action="",
        title="Python Avanzado",
        url="plugin://plugin.video.youtube/channel/"+yt_playlist_2+"/",
        thumbnail=icon,
        fanart=fanart,
        folder=True)

plugintools.add_item(
        action="",
        title="Android studio",
        url="plugin://plugin.video.youtube/channel/"+yt_playlist_3+"/",
        thumbnail=icon,
        fanart=fanart,
        folder=True)

plugintools.add_item(
        action="",
        title="mi primera pagina web Wordpress",
        url="plugin://plugin.video.youtube/channel/"+yt_playlist_4+"/",
        thumbnail=icon,
        fanart=fanart,
        folder=True)

plugintools.add_item(
        action="",
        title="Wordpress para desarrolladores",
        url="plugin://plugin.video.youtube/channel/"+yt_playlist_5+"/",
        thumbnail=icon,
        fanart=fanart,
        folder=True)

plugintools.add_item(
        action="",
        title="curso Firebase 2017",
        url="plugin://plugin.video.youtube/channel/"+yt_playlist_6+"/",
        thumbnail=icon,
        fanart=fanart,
        folder=True)

plugintools.add_item(
        action="",
        title="curso Laralel",
        url="plugin://plugin.video.youtube/channel/"+yt_playlist_7+"/",
        thumbnail=icon,
        fanart=fanart,
        folder=True)

plugintools.add_item(
        action="",
        title="Curso django",
        url="plugin://plugin.video.youtube/channel/"+yt_playlist_8+"/",
        thumbnail=icon,
        fanart=fanart,
        folder=True)
plugintools.add_item(
        action="",
        title="Curso jQuery",
        url="plugin://plugin.video.youtube/channel/"+yt_playlist_9+"/",
        thumbnail=icon,
        fanart=fanart,
        folder=True)

run()
